using System;
/// <summary>
/// This class just supports a challenge from "Introducing
/// Construction."
/// </summary>
public class Fuse
{
//    private string _name;
//    public Fuse(string name) { this._name = name; }
}
/// <summary>
/// This class just supports a challenge from "Introducing
/// Construction."
/// </summary>
public class QuickFuse : Fuse
{
}