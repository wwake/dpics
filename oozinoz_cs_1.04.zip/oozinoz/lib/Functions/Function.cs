namespace Functions
{
    public delegate double Function (double t); 
}
