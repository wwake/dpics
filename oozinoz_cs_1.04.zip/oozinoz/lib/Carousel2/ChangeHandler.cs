namespace Carousel2
{
    /// <summary>
    /// A minimal delegate type.
    /// </summary>
    public delegate void ChangeHandler();
}
